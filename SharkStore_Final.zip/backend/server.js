const express = require('express');
const app = express();
app.use(express.json());

app.get('/', (req,res)=>res.json({status:"Backend SharkStore online"}));

// PIX placeholder
app.post('/pix/webhook', (req,res)=>{ console.log("PIX recebido"); res.sendStatus(200); });

// Afiliados placeholder
app.get('/afiliados', (req,res)=>{ res.json({msg:"Sistema de afiliados ativo"}); });

app.listen(3000, ()=>console.log("Backend rodando na porta 3000"));
